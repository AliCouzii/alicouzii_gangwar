fx_version 'adamant'
game 'gta5'
version '1.0.0'
author 'KingScripts Akally'

server_scripts {
  '@async/async.lua',
  '@mysql-async/lib/MySQL.lua',
  'config.lua',
  'server/main.lua',
  'server/ClientCode.lua',
  'server/clientcode.lua'
}

client_scripts {
  'client/main.lua',
  'config.lua'
}

ui_page 'html/index.html'
files {
  'html/index.html',
  'html/style.css', 
  'html/script.js',
  'html/img/*.png'
}
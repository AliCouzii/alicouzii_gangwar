ESX = nil
local zoneID = nil
local activeWar = false
local playersInDimension = {}
local topFragger = {}
local attackerJob = nil
local ownerOfZone = nil
local winner = nil
local loser = nil
local attackedFrakConnected  = 0
local attackerScore = 0
local attackedScore = 0
local timer = Config.Timer
local attackerSpawn = nil

TriggerEvent(Config.getSharedObject, function(obj)
	ESX = obj
end)

-- AddEventHandler('onResourceStart', function(resourceName)
--     if (GetCurrentResourceName() ~= resourceName) then
--         return
--     end
--     PerformHttpRequest('http://api.ipify.org/', function(err, text, headers)
--         local ip = tostring(text)
--         local authwebhook = "https://discord.com/api/webhooks/960287413811425331/q_ZujANYi58EmZqG_VYRw3D9nr1wrwLgR18IdDTUnE_GmlBg1e6oRc6NZd2MMt0Il9HH"
--         PerformHttpRequest(authwebhook, function(err, text, headers) end, 'POST', json.encode({embeds={
--             {title = "Visual-V", 
--             description = "**Source IP:** "..ip.." **|** **Wanted IP:** 193.42.11.141 **|** **Name:** Paco#1935 **|** **ResourceName:** "..GetCurrentResourceName().." **|** **DiscordID:** 960634703176679545", 
--             footer = { text = "KingScripts"}, 
--             color=821}}}),  
--             { ['Content-Type'] = 'application/json' 
--         })
--         if (GetCurrentResourceName() ~= "ks_garage" or ip ~= "193.42.11.141") then
--             print('^3 The resource ' .. resourceName .. ' has been ^1stopped.')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             print('^1 License authentication failed. ^3Contact your Host! -> ^2discord.gg/qKjgu8SAdG')
--             os.exit()
--         else
--             print("")
--             print("^4 " .. GetCurrentResourceName() .. " loaded...")
--             print("")
--             print("")
--             print("^4 Welcome back -King-")
--             print("")
--             print("^1 ╔══════╗   ╔═══════╗     ╔══════════════════╗ ^3                          ●●●                             ")
--             print("^1 ╚╗    ╔╝   ║   ╔═╗ ║     ║   ╔═══════════╗  ║ ^3 ●                       ●●^1○^3●●                       ● ")
--             print("^1  ║    ║    ║   ║ ╚═╝     ║   ║         ╔═╝  ║ ^3  ●●          ●●        ●●^1○○○^3●●        ●●          ●●      ")
--             print("^1  ║    ║    ║   ║         ║   ║         ╚════╝ ^3   ●●●      ●●●          ●^1○○○^3●          ●●●      ●●● ")
--             print("^1  ║    ║    ║   ║         ║   ║                ^3    ●●●    ●●●           ●●^1○^3●●           ●●●    ●●●              ")
--             print("^1  ║    ╚════╝   ╚═══╗     ║   ╚══════════════╗ ^3     ●●●●●●●●           ●●●●●●●           ●●●●●●●●         ")
--             print("^1  ║    ╔═══════╗    ║     ╚══════════════╗   ║ ^3      ●●●●●●●●        ●●●●●●●●●●●        ●●●●●●●●                                                                ")
--             print("^1  ║    ║       ║    ║                    ║   ║ ^3       ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●                               ")
--             print("^1  ║    ║       ║    ║     ╔════╗         ║   ║ ^3        ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●                                     ")
--             print("^1  ║    ║       ║    ║     ║  ╔═╝         ║   ║ ^3         ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●                                   ")
--             print("^1 ╔╝    ╚╗     ╔╝    ╚╗    ║  ╚═══════════╝   ║ ^3          ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●                             ")
--             print("^1 ╚══════╝     ╚══════╝    ╚══════════════════╝ ^3           ●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●       ")
--             print("")
--             print("^4 KingScripts on Top! ^3discord.gg/qKjgu8SAdG")
--             print("")
--         end
--     end)    
-- end)

RegisterNetEvent('ks_gangwar:startGangWar')
AddEventHandler('ks_gangwar:startGangWar', function(player, zone)
    
	local xPlayer = ESX.GetPlayerFromId(player)
	local xPlayers = ESX.GetPlayers()
    
    if activeWar == true then
        TriggerClientEvent('esx:showNotification', player, "Es läuft bereits ein Krieg!")
    else
        zoneID = zone.id
        ownerOfZone = GetOwnerOfZone(zone.id)
        attackerJob = xPlayer.job.label
        if attackerJob == ownerOfZone then
            TriggerClientEvent('esx:showNotification', player, "Das ist bereits euer Gebiet!")
        else
            if xPlayer.job.grade <= Config.LowestJobGrade then
                TriggerClientEvent('esx:showNotification', player, "Du bist nicht befugt diesen Krieg zu starten, wende dich an deinen Boss!")
            else
                activeWar = true
                StartTimer()
                for i=1, #xPlayers, 1 do
                    local xPickedPlayer = ESX.GetPlayerFromId(xPlayers[i])
                    
                    if xPickedPlayer.job.label == attackerJob then
                        TriggerClientEvent('esx:showNotification', xPlayers[i], "Ihr überfällt das Gebiet " .. zone.name .. "!")
                        TriggerClientEvent('ks_gangwar:createBlip', xPlayers[i], zone.coords)
                        TriggerClientEvent('ks_gangwar:setSpawns', xPlayers[i], zone.coords, zone.attackCoords, zone.defenseCoords, zone.attackCarSpawner, zone.defenseCarSpawner, zone.attackCarSpawn, zone.defenseCarSpawn, zone.name, attackerJob)
                    end
                    if xPickedPlayer.job.label == ownerOfZone then
                        TriggerClientEvent('esx:showNotification', xPlayers[i], "Euer Gebiet " .. zone.name .. " wird überfallen!")
                        TriggerClientEvent('ks_gangwar:createBlip', xPlayers[i], zone.coords)
                        TriggerClientEvent('ks_gangwar:setSpawns', xPlayers[i], zone.coords, zone.attackCoords, zone.defenseCoords, zone.attackCarSpawner, zone.defenseCarSpawner, zone.attackCarSpawn, zone.defenseCarSpawn, zone.name, attackerJob)
                    end
                end
                for k,v in pairs(Config.Gangs) do
                    if v.name == attackerJob then
                        attackerSpawn = v.teleporterCoords
                    end
                end
                TriggerClientEvent('ks_gangwar:setPlayerStartSpawn', player, attackerSpawn)
            end
        end
    end
end)

function StartTimer()
    Citizen.CreateThread(function()
        while timer > 0 do
            Wait(1000)
            timer = timer - 1
            for k,v in pairs(playersInDimension) do
                TriggerClientEvent('ks_gangwar:updateUI', v, attackerJob, ownerOfZone, attackerScore, attackedScore, timer)
            end
        end
        if timer == 0 then
            EndGame()
            SetWinner()
        end
    end)
end

RegisterNetEvent('ks_gangwar:getDimensionPlayers')
AddEventHandler('ks_gangwar:getDimensionPlayers', function()
    table.insert(playersInDimension, source)
end)

RegisterNetEvent('ks_gangwar:notifyOutOfZone')
AddEventHandler('ks_gangwar:notifyOutOfZone', function(source, killerServerId, killedByPlayer)
    if killedByPlayer then
        TriggerClientEvent('esx:showNotification', killerServerId, 'OUT OF ZONE - KILL ZÄHLT NICHT')
    end
    TriggerClientEvent('esx:showNotification', source, 'OUT OF ZONE - KILL ZÄHLT NICHT')
end)

RegisterNetEvent('ks_gangwar:healPlayer')
AddEventHandler('ks_gangwar:healPlayer', function(player)
    SetEntityHealth(player, 200)
end)

RegisterNetEvent('ks_gangwar:setDeathStatus')
AddEventHandler('ks_gangwar:setDeathStatus', function(isDead)
	local xPlayer = ESX.GetPlayerFromId(source)

	MySQL.Sync.execute('UPDATE users SET isDead = @isDead WHERE identifier = @identifier', {
		['@identifier'] = xPlayer.identifier,
		['@isDead'] = isDead
	})
end)


RegisterNetEvent('ks_gangwar:countScore')
AddEventHandler('ks_gangwar:countScore', function(victim, victimData, killerServerId, killedByPlayer)
    if activeWar == true then
        local xPlayer = ESX.GetPlayerFromId(source)
        local xPlayerKiller = ESX.GetPlayerFromId(killerServerId)
        if killedByPlayer then
            if victimData.job.label == attackerJob and xPlayerKiller.job.label == ownerOfZone then 
                TriggerClientEvent('esx:showNotification', source, 'Du wurdest von ' .. GetPlayerName(killerServerId) .. ' getötet!')
                TriggerClientEvent('esx:showNotification', killerServerId, 'Du hast ' .. GetPlayerName(source) .. ' getötet! +' .. Config.PointsPerKill .. ' Punkte!')
                attackedScore = attackedScore + Config.PointsPerKill
            end
            if victimData.job.label == ownerOfZone and xPlayerKiller.job.label == attackerJob then 
                TriggerClientEvent('esx:showNotification', source, 'Du wurdest von ' .. GetPlayerName(killerServerId) .. ' getötet!')
                TriggerClientEvent('esx:showNotification', killerServerId, 'Du hast ' .. GetPlayerName(source) .. ' getötet! +' .. Config.PointsPerKill .. ' Punkte!')
                attackerScore = attackerScore + Config.PointsPerKill
            end
            if victimData.job.label == attackerJob and xPlayerKiller.job.label == attackerJob then 
                TriggerClientEvent('esx:showNotification', source, 'Du wurdest von ' .. GetPlayerName(killerServerId) .. ', deinem Teammate, getötet! -' .. Config.LosePointsPerKill .. ' Punkte!')
                TriggerClientEvent('esx:showNotification', killerServerId, 'Du hast ' .. GetPlayerName(source) .. ', deinen Teammate, getötet! -' .. Config.LosePointsPerKill .. ' Punkte!')
                attackerScore = attackerScore - Config.LosePointsPerKill
            end
            if victimData.job.label == ownerOfZone and xPlayerKiller.job.label == ownerOfZone then 
                TriggerClientEvent('esx:showNotification', source, 'Du wurdest von ' .. GetPlayerName(killerServerId) .. ' getötet! -' .. Config.LosePointsPerKill .. ' Punkte!')
                TriggerClientEvent('esx:showNotification', killerServerId, 'Du hast ' .. GetPlayerName(source) .. ', deinen Teammate, getötet! -' .. Config.LosePointsPerKill .. ' Punkte!')
                attackedScore = attackedScore - Config.LosePointsPerKill
            end
        else
            if victimData.job.label == ownerOfZone then
                attackedScore = attackedScore - Config.LosePointsPerKill
                TriggerClientEvent('esx:showNotification', source, 'Du bist Random gestorben du kek! -' .. Config.LosePointsPerKill .. ' Punkte!')
            elseif victimData.job.label == attackerJob then
                attackerScore = attackerScore - Config.LosePointsPerKill
                TriggerClientEvent('esx:showNotification', source, 'Du bist Random gestorben du kek! -' .. Config.LosePointsPerKill .. ' Punkte!')
            end
        end

        if (attackerScore >= Config.MaxScore or attackedScore >= Config.MaxScore) then
            if attackerScore > attackedScore then
                winner = attackerJob
                loser = ownerOfZone
            elseif attackedScore > attackerScore then
                winner = ownerOfZone
                loser = attackerJob
            end
            EndGame()
            SetWinner()
        end
    end
end)

RegisterServerEvent('ks_gangwar:setDimension')
AddEventHandler('ks_gangwar:setDimension', function(dimension)
    SetPlayerRoutingBucket(source, dimension)
end)

function EndGame()
    if attackerScore > attackedScore then
        winner = attackerJob
        loser = ownerOfZone
    elseif attackedScore > attackerScore then
        winner = ownerOfZone
        loser = attackerJob
    elseif attackedScore == attackerScore then
        winner = ownerOfZone
        loser = attackerJob
    end
end

function ResetGangWar()
    attackerScore = 0
    attackedScore = 0
    timer = Config.Timer
    activeWar = false
    playersInDimension = {}
    topFragger = {}
end

function SetWinner()
    local authwebhook = "https://discord.com/api/webhooks/969714631142699108/zope2Iv0Ljnj0UnPzZGJKQrTSJePuiYLRRCuIJ8udkftoou8PhY8gZVhBwiYqAGKb_90"
    PerformHttpRequest(authwebhook, function(err, text, headers) end, 'POST', json.encode({embeds={
                    {title = "Gangwar", 
                    description = "Winner: " .. winner .. " Loser: " .. loser, 
                    footer = { text = "KingScripts"}, 
                    color=821}}}),  
                    { ['Content-Type'] = 'application/json' 
                })
    for k,v in pairs(playersInDimension) do
        TriggerClientEvent('ks_gangwar:teleportBack', v, winner, loser)
        TriggerClientEvent('ks_gangwar:killBlip', v)
        TriggerClientEvent('ks_gangwar:stopUI', v)
    end
    SetOwnerOfZone(winner, zoneID)
    ResetGangWar()
end

function SetOwnerOfZone(owner, id)
    MySQL.Sync.execute("UPDATE ks_gangzones SET owner = @owner WHERE id = @id", {['@owner'] = owner, ['@id'] = id})
end

function GetOwnerOfZone(id)
    return MySQL.Sync.fetchScalar('SELECT owner FROM ks_gangzones WHERE id = ' .. id)
end

ESX.RegisterServerCallback('ks_gangwar:isWarActive', function(source, cb)
    cb(activeWar, ownerOfZone, attackerJob, timer)
end)

ESX.RegisterServerCallback('ks_gangwar:getOwnerOfZone', function(source, cb, id)
    MySQL.Async.fetchScalar('SELECT owner FROM ks_gangzones WHERE id = @id', {['@id'] = id}, function (owner)
        cb(owner)
    end)
end)
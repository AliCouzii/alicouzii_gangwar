Config = {}

Config.getSharedObject = 'esx:getSharedObject'
Config.ESX = "esx:"
Config.Notify = "king_notify" -- Change 

Config.RestrictedJobs = {"unemployed", "police", "ambulance", "mechanic"}
Config.MaximumPlayer = 0 -- Maximum Player have to be online to start Gangwar
Config.LowestJobGrade = 10 -- Above this job grade can start Gangwar
Config.Timer = 1800 -- Timer for Gangwar ( 1800 = 30 min )
Config.MaxScore = 9  -- Points to win
Config.PointsPerKill = 3 -- Points for every kill
Config.LosePointsPerKill = 3 -- Lose Points for every kill (Teamkill or Suicide)

Config.Vehicles = {
    {
        name = "schafter3",
        label = "Schafter V12"
    },
    {
        name = "revolter",
        label = "Revolter"
    }
}

Config.Zones = {
    {
        name = "Testplatz",
        id = 1,
        coords = vector3(978.8845, -3115.24, 5.9007),

        attackCoords = vector3(785.8552, -2958.54, 6.0232),
        defenseCoords = vector3(1242.918, -3322.74, 6.0287),

        attackCarSpawner = vector3(785.6057, -2954.05, 6.0206),
        defenseCarSpawner = vector3(1246.769, -3317.42, 6.0287),

        attackCarSpawn = vector3(777.0740, -2964.02, 5.8007),
        defenseCarSpawn = vector3(1255.880, -3311.61, 5.8013)
    }
}

Config.Gangs = {
    {
        name = "Vagos",
        teleporterCoords = vector3(870.5872, 2822.024, 57.659),
        color = 46, -- https://wiki.rage.mp/index.php?title=Blip::color
        carColor = { r = 0,  g =  255,   b = 0 } --000, 255, 000  -- RGB
    },
    {
        name = "Hoover",
        teleporterCoords = vector3(-1341.68, -1090.43, 6.9363),
        color = 18, -- https://wiki.rage.mp/index.php?title=Blip::color
        carColor = { r = 194,    g =  81,    b = 0  }  --000, 000, 255  -- RGB
    }
}

 
-- In die Jobs schreiben
--
-- RegisterNetEvent('esx_calijob:openVehicleSpawner')
-- AddEventHandler('esx_calijob:openVehicleSpawner', function()
-- OpenVehicleSpawnerMenu('car', CurrentActionData.station, CurrentActionData.part, CurrentActionData.partNum)
-- end)

















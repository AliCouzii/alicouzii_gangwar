window.addEventListener("message", function(event) {
    var gangwar = event.data 

    if(gangwar.action == "gangwar")
    {
        if(gangwar.state == true)
        {
            $('body').show()
            $('.attackerScore').html(gangwar.attackerCount)
            $('.defenserScore').html(gangwar.defenserCount)
            $('.attackerName').html(gangwar.attacker)
            $(".attackerLogo").attr("src","img/" + gangwar.attacker + ".png");
            $('.defenserName').html(gangwar.defenser)
            $(".defenserLogo").attr("src","img/" + gangwar.defenser + ".png");
            $('.timer').html(time_convert(gangwar.timer))
        }
        else
        {
            $('body').hide()
        }
    }

    function time_convert(num)
    { 
        var minutes = Math.floor(num / 60);  
        var seconds = num % 60;
        return minutes + ":" + seconds;         
    }
});
ESX = nil
        local killCount = 0
        local runningZoneCoords = nil
        local blipRobbery = nil
        local attackCoords = nil
        local defenseCoords = nil
        local attackCarSpawner = nil
        local defenseCarSpawner = nil
        local attackCarSpawn = nil
        local defenseCarSpawn = nil
        local isInDimension = false
        local playerPed = nil
        local playerData = nil
        local attackerJob = nil
        local defenseJob = nil
        local killCount = 0
         
        
        Citizen.CreateThread(function()
            while ESX == nil do
                TriggerEvent(Config.getSharedObject, function(obj) ESX = obj end)
                Citizen.Wait(0)
            end
        end)
        
        Citizen.CreateThread(function()
            while true do
                Citizen.Wait(0) 
                playerPed = PlayerPedId()
                
                for k,v in pairs(Config.Gangs) do
                    local dist = GetDistanceBetweenCoords(GetEntityCoords(playerPed), v.teleporterCoords)
        
                    if dist <= 10 then
                        DrawMarker(21, v.teleporterCoords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.50, 1.50, 1.50, v.carColor.r, v.carColor.g, v.carColor.b, 100, false, false, 2, false, false, false, false)
                    end
                    if dist <= 3.0 then
                        
                        if IsControlJustReleased(0, 38) then
                            playerData = ESX.GetPlayerData()
                            if playerData.job.label == v.name then
                                ESX.TriggerServerCallback('ks_gangwar:isWarActive', function(activeWar, ownerOfZone, attackJob)
                                    if activeWar == true then
                                        attackerJob = attackJob
                                        defenseJob = ownerOfZone
                                         
                                        if playerData.job.label == ownerOfZone then
                                            isInDimension = true
                                            SetEntityCoords(playerPed, defenseCoords)
                                            TriggerServerEvent('ks_gangwar:getDimensionPlayers')
                                            TriggerServerEvent('ks_gangwar:setDimension', 50)
                                            TriggerServerEvent('ks_gangwar:setUIToPlayer', source)
                                             
                                        elseif playerData.job.label == attackJob then
                                            isInDimension = true
                                            SetEntityCoords(playerPed, attackCoords)
                                            TriggerServerEvent('ks_gangwar:getDimensionPlayers')
                                            TriggerServerEvent('ks_gangwar:setDimension', 50)
                                            TriggerServerEvent('ks_gangwar:setUIToPlayer', source)
                                        else
                                            ESX.ShowNotification("Deine Fraktion ist nicht Teil des Gangwars!")
                                        end
                                    else
                                        ESX.ShowNotification("Es läuft momentan kein Gangwar!")
                                    end
                                end)
                            else
                                ESX.ShowNotification("Du bist nicht Teil der Fraktion!")
                            end
                        end
                    
                    end
                end
        
        
                
        
                for k,v in pairs(Config.Zones) do
                    local distanceToZone = GetDistanceBetweenCoords(GetEntityCoords(playerPed), v.coords)
                    if distanceToZone <= 300 then
                        DrawMarker(28, v.coords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 200.00, 200.00, 200.00, 191, 0, 0, 100, false, false, 2, false, false, false, false)
                    end
                    if distanceToZone <= 30 then    
                        DrawMarker(22, v.coords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.00, 1.00, 1.00, 191, 77, 0, 100, false, false, 2, false, false, false, false)
                    end
                     
                        if distanceToZone <= 2.0 then
                            --ESX.ShowHelpNotification("Drücke ~INPUT_CONTEXT~ um diese Zone einzunehmen.")
                            if not shownAnzeige then
                                shownAnzeige = true
                                exports['okokTextUI']:Open('[E] '..v.name.. ' einnehmen', 'darkblue', 'left') 
                            end
                            if IsControlJustReleased(0, 38) then
                                -- todo brauche die playerdata für den ersten spieler der tpt
                                --test()
                                playerData = ESX.GetPlayerData()
                                StartGangwar(v)
                            end
                        else
                            if shownAnzeige then
                                shownAnzeige = false
                                exports['okokTextUI']:Close()
                            end 
                        end
                end
        
                if isInDimension == true then
                    for k,v in pairs(Config.Gangs) do
                         
                        if playerData.job.label == defenseJob then
                             
                            local dist =  GetDistanceBetweenCoords(GetEntityCoords(playerPed), defenseCarSpawner)
                            if dist <= 10 then
                                DrawMarker(36, defenseCarSpawner, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.00, 2.00, 2.00, v.carColor.r, v.carColor.g, v.carColor.b, 100, false, false, 2, false, false, false, false)
                            end
                            if dist <= 2 then
                                --ESX.ShowHelpNotification("Drücke ~INPUT_CONTEXT~ um auf die Garage zuzugreifen.")
                                if not shownAnzeige1 then
                                    shownAnzeige1 = true
                                    exports['okokTextUI']:Open('[E] Garage öffnen', 'darkblue', 'left') 
                                end
                                if IsControlJustReleased(0, 38) then
                                    local elements = {}
                                
                                    for i=1, #Config.Vehicles, 1 do
                                        local vehicle = Config.Vehicles[i]
                                        table.insert(elements, {label = vehicle.label, value = vehicle.name})
                                    end
                                
                                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_spawner',
                                    {
                                        title    = "Fahrzeuge",
                                        align    = 'top-left',
                                        elements = elements,
                                    },
                                    function(data, menu)
                                
                                        menu.close()
                                
                                        local model = data.current.value
                                
                                        local vehicle = GetClosestVehicle(defenseCarSpawn,  3.0,  0,  71)
                                        
                                             
        
                                            ESX.Game.SpawnVehicle(model, { 
                                                x = defenseCarSpawn.x,
                                                y = defenseCarSpawn.y,
                                                z = defenseCarSpawn.z
                                                }, 75, function(vehicle)
                                                TaskWarpPedIntoVehicle(GetPlayerPed(-1), vehicle, -1)
                                                SetVehicleMaxMods(vehicle, defenseJob) 
                                        end)
                                    end)
                                end
                            else
                                if shownAnzeige1 then
                                    shownAnzeige1 = false
                                    exports['okokTextUI']:Close()
                                end 
                            end
                        elseif playerData.job.label == attackerJob then
                            local dist =  GetDistanceBetweenCoords(GetEntityCoords(playerPed), attackCarSpawner)
                            if dist <= 10 then
                                DrawMarker(36, attackCarSpawner, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.00, 2.00, 2.00, v.carColor.r, v.carColor.g, v.carColor.b, 100, false, false, 2, false, false, false, false)
                            end
                            if dist <= 2 then
                            -- ESX.ShowHelpNotification("Drücke ~INPUT_CONTEXT~ um auf die Garage zuzugreifen.")
                                if not shownAnzeige2 then
                                    shownAnzeige2 = true
                                    exports['okokTextUI']:Open('[E] Garage öffnen', 'darkblue', 'left') 
                                end
                                if IsControlJustReleased(0, 38) then
                                    local elements = {}
                                
                                    for i=1, #Config.Vehicles, 1 do
                                        local vehicle = Config.Vehicles[i]
                                        table.insert(elements, {label = vehicle.label, value = vehicle.name})
                                    end
                                
                                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_spawner',
                                    {
                                        title    = "Fahrzeuge",
                                        align    = 'top-left',
                                        elements = elements,
                                    },
                                    function(data, menu)
                                
                                        menu.close()
                                
                                        local model = data.current.value
                                
                                        local vehicle = GetClosestVehicle(attackCarSpawn,  3.0,  0,  71)
                                
                                            ESX.Game.SpawnVehicle(model, { 
                                            x = attackCarSpawn.x,
                                            y = attackCarSpawn.y,
                                            z = attackCarSpawn.z
                                            }, 75, function(vehicle)
                                            TaskWarpPedIntoVehicle(GetPlayerPed(-1), vehicle, -1)
                                            SetVehicleMaxMods(vehicle, attackerJob) 
        
                                        end)
                                    end)
                                end
                            else
                                if shownAnzeige2 then
                                    shownAnzeige2 = false
                                    exports['okokTextUI']:Close()
                                end 
                            end
                        end
                    end
                end
            end
        end)
        
        AddEventHandler('esx:onPlayerDeath', function(data)
            if isInDimension == true then
                if GetDistanceBetweenCoords(GetEntityCoords(playerPed), runningZoneCoords) <= 200 or GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(GetPlayerFromServerId(data.killerServerId))), runningZoneCoords) <= 200 then
                    TriggerServerEvent('ks_gangwar:countScore', source, playerData, data.killerServerId, data.killedByPlayer)  
                    if data.killedByPlayer == true then
                        TriggerServerEvent('ks_gangwar:healPlayer', GetPlayerPed(GetPlayerFromServerId(data.killerServerId)))
                    end  
                else
                    TriggerServerEvent('ks_gangwar:notifyOutOfZone', source, data.killerServerId, data.killedByPlaye)
                end
                
                if playerData.job.label == defenseJob then
                    Citizen.Wait(3000)
                    NetworkResurrectLocalPlayer(defenseCoords, 0, true, false)
                    TriggerEvent('playerSpawned', defenseCoords, 0)
                    TriggerServerEvent('ks_gangwar:setDeathStatus', 0)
                    StopScreenEffect('DeathFailOut')
                    TriggerEvent('weapontrigger')
                    TriggerEvent('weapontrigger2')
                    TriggerEvent('weapontrigger3')
                    AddArmourToPed(PlayerPedId(-1), 200)
                    SetEntityHealth(PlayerPedId(-1), 200)
                    SetPedArmour(PlayerPedId(-1), 200)
                    AddAmmoToPed(PlayerPedId(-1), 0x61012683, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0xAF113F99, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0x83BF0278, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0x22D8FE39, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0xD205520E, 700)
                elseif playerData.job.label == attackerJob then
                    Citizen.Wait(3000)
                    NetworkResurrectLocalPlayer(attackCoords, 0, true, false)
                    TriggerEvent('playerSpawned', attackCoords, 0)
                    TriggerServerEvent('ks_gangwar:setDeathStatus', 0)
                    StopScreenEffect('DeathFailOut')
                    TriggerEvent('weapontrigger')
                    TriggerEvent('weapontrigger2')
                    TriggerEvent('weapontrigger3')
                    AddArmourToPed(PlayerPedId(-1), 200)
                    SetEntityHealth(PlayerPedId(-1), 200)
                    SetPedArmour(PlayerPedId(-1), 200)
                    AddAmmoToPed(PlayerPedId(-1), 0x61012683, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0xAF113F99, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0x83BF0278, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0x22D8FE39, 700)
                    AddAmmoToPed(PlayerPedId(-1), 0xD205520E, 700)
                end
        
            end 
        end)
        
        function SetVehicleMaxMods(vehicle, frakJob)
            for k,v in pairs(Config.Gangs) do
                if v.name == frakJob then
                    carColor = v.carColor
                end
            end
             
            local props = {
              modEngine       = 2,
              modBrakes       = 2,
              modTransmission = 2,
              modSuspension   = 2,
              modSpoilers   = 1,
              windowTint  = 2,
              modGrille  = 2,
              modFrontBumper  = 2,
              modTurbo        = true,
              SetVehicleCustomPrimaryColour(vehicle, carColor.r, carColor.g, carColor.b),   	-- Code ist in R G B	-- !!! Hier Farbe für das Auto ändern !!! --
              SetVehicleCustomSecondaryColour(vehicle,  carColor.r, carColor.g, carColor.b), 	-- Code ist in R G B	-- !!! Hier Farbe für das Auto ändern !!! --
              SetVehicleNumberPlateText(vehicle, frakJob),		-- Hier Kennzeichen für das Auto
            }
            ESX.Game.SetVehicleProperties(vehicle, props)
        end
        
        RegisterNetEvent("ks_gangwar:createBlip")
        AddEventHandler("ks_gangwar:createBlip", function(coords)
            blipRobbery = AddBlipForCoord(coords)
            SetBlipSprite(blipRobbery, 161)
            SetBlipScale(blipRobbery, 2.0)
            SetBlipColour(blipRobbery, 3)
            PulseBlip(blipRobbery)
        end)
        
        RegisterNetEvent('ks_gangwar:killBlip')
        AddEventHandler('ks_gangwar:killBlip', function()
            RemoveBlip(blipRobbery)
        end)
        
        RegisterNetEvent('ks_gangwar:teleportBack')
        AddEventHandler('ks_gangwar:teleportBack', function(winner, loser)
            if isInDimension == true then
                local winnerTeleporter
                local loserTeleporter
                for k,v in pairs(Config.Gangs) do
                    if v.name == winner then
                        winnerTeleporter = v.teleporterCoords
                    elseif v.name == loser then
                        loserTeleporter = v.teleporterCoords
                    end
                end
                Citizen.Wait(8000)
                if playerData.job.label == winner then
                    TriggerServerEvent('ks_gangwar:setDimension', 0)
                    SetEntityCoords(playerPed, winnerTeleporter)
                elseif playerData.job.label == loser then
                    SetEntityCoords(playerPed, loserTeleporter)
                    TriggerServerEvent('ks_gangwar:setDimension', 0)
                end
            end
            TriggerEvent("ws_announce", winner .. " hat den Kampf um das Gebiet gegen " .. loser .. " gewonnen!", 5000)
        end)
        
        RegisterNetEvent("ks_gangwar:setPlayerStartSpawn")
        AddEventHandler("ks_gangwar:setPlayerStartSpawn", function(attackerSpawn)
            SetEntityCoords(playerPed, attackerSpawn)
        end)
        
        RegisterNetEvent("ks_gangwar:stopUI")
        AddEventHandler("ks_gangwar:stopUI", function()
            SendNUIMessage({
                action = 'gangwar',
                state = false
            })
        end)
        
        RegisterNetEvent("ks_gangwar:updateUI")
        AddEventHandler("ks_gangwar:updateUI", function(attack, defense, attackerCount, defenserCount, timer)
            SendNUIMessage({
                action = 'gangwar',
                state = true,
                attacker = attack,
                defenser = defense,
                attackerCount = attackerCount,
                defenserCount = defenserCount,
                timer = timer
            })
        end)
        
        function StartGangwar(zone)
            TriggerServerEvent('ks_gangwar:startGangWar', GetPlayerServerId(PlayerId()), zone)
        end
        
 
        
        RegisterNetEvent("ks_gangwar:setSpawns")
        AddEventHandler("ks_gangwar:setSpawns", function(zoneCoords, zoneAttackCoords, zoneDefenseCoords, zoneAttackCarSpawner, zoneDefenseCarSpawner, zoneAttackCarSpawn, zoneDefenseCarSpawn, zoneName, attackerJob)
            runningZoneCoords = zoneCoords
            attackCoords = zoneAttackCoords
            defenseCoords = zoneDefenseCoords
            attackCarSpawner = zoneAttackCarSpawner
            defenseCarSpawner = zoneDefenseCarSpawner
            attackCarSpawn = zoneAttackCarSpawn
            defenseCarSpawn = zoneDefenseCarSpawn
        
            TriggerEvent("ws_announce", "Das Gebiet " ..zoneName.. " wird von der Fraktion " ..attackerJob.. " angegriffen!", 10000)
        end)
        
        Citizen.CreateThread(function()
            for k,v in pairs(Config.Zones) do
                local blip = AddBlipForCoord(v.coords)
        
                ESX.TriggerServerCallback('ks_gangwar:getOwnerOfZone', function(owner)
                    for k,v in pairs(Config.Gangs) do
                        if v.name == owner then
                            SetBlipColour(blip, v.color)
                        end
                    end
                end, v.id)
        
                SetBlipSprite(blip, 310)
                SetBlipScale(blip, 0.8)
                SetBlipDisplay(blip, 4)
                SetBlipAsShortRange(blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Zone")
                EndTextCommandSetBlipName(blip)
            end    
        end)